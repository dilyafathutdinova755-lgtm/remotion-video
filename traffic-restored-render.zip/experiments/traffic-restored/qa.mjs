export function layoutIssues(boxes,width=1080,height=1920) {
  const issues=[];
  for(const b of boxes) {
    if(![b.x,b.y,b.w,b.h].every(Number.isFinite) || b.w<=0 || b.h<=0 || b.x<-.5 || b.y<-.5 || b.x+b.w>width+.5 || b.y+b.h>height+.5 || b.overflow) issues.push({kind:'bounds',box:b});
  }
  for(let i=0;i<boxes.length;i++)for(let j=i+1;j<boxes.length;j++){
    const a=boxes[i],b=boxes[j],w=Math.min(a.x+a.w,b.x+b.w)-Math.max(a.x,b.x),h=Math.min(a.y+a.h,b.y+b.h)-Math.max(a.y,b.y);
    if(w>8&&h>8)issues.push({kind:'overlap',a:a.text,b:b.text,area:w*h});
  }
  return issues;
}
export function requireCleanRender(layout,errors=[]) {
  if(!layout.length)throw Error('No frames inspected');
  if(errors.length)throw Error(`Browser rendering failed: ${errors.join('; ')}`);
  const bad=layout.filter(f=>f.issues.length);
  if(bad.length)throw Error(`Layout failed on ${bad.length} frames; inspect layout-qa.json`);
}
export function frameRange({fps,workers,from,to,duration}) {
  if(fps!==120)throw Error('Approved template requires 120 FPS');
  if(!Number.isInteger(workers)||workers<1||workers>6)throw Error('Invalid worker count');
  if(![from,to,duration].every(Number.isFinite)||from<0||to>duration+1/120||to<=from)throw Error('Invalid frame range');
  const first=Math.round(from*fps),last=Math.round(to*fps);
  if(last<=first)throw Error('Empty frame range');
  return {first,last};
}
