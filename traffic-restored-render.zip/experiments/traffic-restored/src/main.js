import * as THREE from 'three';
import {makeStory} from './story.js';
import {createWorld} from './brand-world.js';
import {createOverlay} from './overlay.js';
import {createTraffic} from './traffic-world.js';
import {clamp,ease,seg,lerp} from './lib.js';
import {validateTimeline,presentation,distances,fmt} from './traffic-contract.js';
const base=new URL('..',import.meta.url),tl=await(await fetch(new URL('render-timing.json',base))).json(),baseline=await(await fetch(new URL('brand-baseline.json',base))).json();
const P=validateTimeline(tl);
const S=Object.fromEntries(tl.scenes.map(s=>[s.id,s]));baseline.total=tl.duration;baseline.introSec=2;baseline.condition=tl.condition;
for(const k of Object.keys(baseline.marks))baseline.marks[k]=1000;
Object.assign(baseline.marks,{h1:S.approach.start,h2:S.combine.start,h3:S.divide.start,ans:S.answer.start,cta:S.cta.start,link:S.cta.start+2});
baseline.sentences=[{id:'pause',start:tl.pause.start,end:tl.pause.end},{id:'s7',start:S.divide.start,end:S.divide.end},{id:'ans',start:S.answer.start,end:S.answer.end},{id:'cta',start:S.cta.start,end:S.cta.end}];
const story=makeStory(baseline);story.director=baseline;
const defs=presentation(P);
story.headlines=tl.scenes.map(s=>[s.start,...defs[s.id].slice(0,3)]);story.headlines.push([tl.pause.start,'','','']);story.headlines.sort((a,b)=>a[0]-b[0]);
await Promise.all([500,600,700,800].map(w=>document.fonts.load(`${w} 40px Inter`,'АаЯя08x')));await document.fonts.ready;
const shape=await(await fetch(new URL('assets/logo-shape.json',base))).json(),logo=await new THREE.TextureLoader().loadAsync(new URL('assets/logo.png',base).href);logo.colorSpace=THREE.SRGBColorSpace;logo.anisotropy=8;
const stage=document.querySelector('#stage'),display=document.querySelector('#gl'),ctx=display.getContext('2d'),brandCanvas=document.createElement('canvas');brandCanvas.width=1080;brandCanvas.height=1920;
const overlay=createOverlay(stage,story),world=createWorld({canvas:brandCanvas,logoTexture:logo,logoN:shape.superellipseN,story});overlay.init(world);
const trafficCanvas=document.createElement('canvas');trafficCanvas.width=1080;trafficCanvas.height=850;const traffic=createTraffic(trafficCanvas,P);
function el(cls,html=''){const e=document.createElement('div');e.className=cls;e.innerHTML=html;stage.appendChild(e);return e;}
const noteWrap=el('note-wrap traffic-note','<div class="floor-shadow"></div><div class="note"><div class="note-top"><i></i><i></i><i></i><span>Разбираем по смыслу</span></div><div class="note-line"><span class="nl-text"></span></div></div>');noteWrap.style.top='1430px';
const note=noteWrap.querySelector('.note'),noteText=noteWrap.querySelector('.nl-text');
const labelA=el('sticker'),labelB=el('sticker violet'),distance=el('sticker'),mapLine=el('map-line'),bars=el('hour-blocks');
mapLine.style.cssText='position:absolute;z-index:3;left:285px;top:1180px;width:510px;height:4px;background:#7774d8;border-radius:2px;';mapLine.innerHTML='<i style="position:absolute;left:0;top:-8px;border-right:15px solid #7774d8;border-top:10px solid transparent;border-bottom:10px solid transparent"></i><i style="position:absolute;right:0;top:-8px;border-left:15px solid #7774d8;border-top:10px solid transparent;border-bottom:10px solid transparent"></i>';
bars.style.cssText='position:absolute;z-index:4;left:180px;top:1280px;display:flex;gap:12px;';bars.innerHTML=Array.from({length:P.hours},(_,i)=>`<div style="flex:1;padding:20px 0;border-radius:24px;background:${i%2?'#e2dcff':'#d8dfff'};color:${i%2?'#7860df':'#4864ed'};text-align:center;font-size:${P.hours>3?26:38}px;font-weight:700;box-shadow:0 14px 25px #4a488c25">${fmt(P.sum)} км<br>1 час</div>`).join('');bars.style.width='720px' ;
function sticker(e,text,x,y,k=1){e.textContent=text;e.style.display=text?'':'none';e.style.opacity=k;e.style.transform=`translate(${x}px,${y}px) translate(-50%,-50%) scale(${.88+.12*k})`;}
window.renderFrame=t=>{
 const s=[...tl.scenes].reverse().find(s=>t>=s.start),paused=t>=tl.pause.start&&t<tl.pause.end+.4,c=s?defs[s.id]:null;const content=!!s&&!paused&&s.id!=='cta';
 // Original brand renderer and shutter. Intro is replaced with original compressed frames at final assembly.
 const samples=t<2||t>S.cta.start-.1&&t<S.cta.start+1.35?9:1;ctx.clearRect(0,0,1080,1920);ctx.globalCompositeOperation=samples>1?'lighter':'source-over';ctx.globalAlpha=1/samples;
 for(let i=0;i<samples;i++){world.update(Math.max(0,t+(samples>1?(i/(samples-1)-.5)/120:0)),overlay.plaque);world.hideLegacy();world.render();ctx.drawImage(brandCanvas,0,0);}ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';overlay.update(t,display);
 for(const cls of ['.stickers','.notes','.eq-wrap','.flyers'])document.querySelector(cls).style.display='none';
 noteWrap.style.display='none';labelA.style.display=labelB.style.display=distance.style.display=mapLine.style.display=bars.style.display='none';
 if(content){const u=clamp((t-s.start-.2)/Math.max(.5,s.end-s.start-.7)),progress=ease.inOutCubic(u),paths=distances(P,s.id,progress);
 traffic.update(t,{view:c[3],progress,paths});const fade=ease.outCubic(seg(t,s.start,s.start+.35));ctx.globalAlpha=fade;ctx.drawImage(trafficCanvas,0,670);ctx.globalAlpha=1;
 if(c[4]){noteWrap.style.display='';noteText.textContent=c[4];note.style.transform=`perspective(1500px) translateY(${(1-fade)*100}px) rotateX(${9+(1-fade)*24}deg) rotateY(${-5+Math.sin(t*.6)*1.5}deg)`;note.style.opacity=fade;}
 const pa=traffic.project(traffic.a.g.position.clone().add(new THREE.Vector3(0,1.7,0))),pb=traffic.project(traffic.b.g.position.clone().add(new THREE.Vector3(0,1.7,0)));
 if(['cars','question','approach','closing'].includes(s.id)){sticker(labelA,fmt(P.speed_a)+' км/ч',pa.x,pa.y-15,fade);sticker(labelB,fmt(P.speed_b)+' км/ч',pb.x,pb.y-15,fade);}
 if(['speed_a','speed_b'].includes(s.id))sticker(s.id==='speed_a'?labelA:labelB,fmt(s.id==='speed_a'?P.speed_a:P.speed_b)+' км/ч',540,1250,fade);
 if(['hour_a','hour_b','verify_a','verify_b','verify_sum'].includes(s.id)){
  const split=Math.abs(pa.x-pb.x)<240;
  if(!['hour_b','verify_b'].includes(s.id))sticker(labelA,fmt(paths.a)+' км',pa.x,pa.y-(split?115:30),fade);
  if(!['hour_a','verify_a'].includes(s.id))sticker(labelB,fmt(paths.b)+' км',pb.x,pb.y+(split?40:-30),fade);
 }
 if(c[3]==='map'){sticker(labelA,'Город А',260,1250,fade);sticker(labelB,'Город Б',820,1250,fade);mapLine.style.display='';mapLine.style.opacity=fade;sticker(distance,s.id==='combine'?`${fmt(P.speed_a)} + ${fmt(P.speed_b)}`:`${fmt(P.distance)} км`,540,1180,fade);}
 if(s.id==='divide'){bars.style.display='flex';labelA.style.display=labelB.style.display='none';}
 }
 return true;
};
window.DURATION=tl.duration;window.FPS=120;window.ready=true;
