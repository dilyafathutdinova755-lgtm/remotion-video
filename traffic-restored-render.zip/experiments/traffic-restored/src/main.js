import * as THREE from 'three';
import {makeStory} from './story.js';
import {createWorld} from './brand-world.js';
import {createOverlay} from './overlay.js';
import {createTraffic} from './traffic-world.js';
import {clamp,ease,seg,lerp} from './lib.js';
const base=new URL('..',import.meta.url),tl=await(await fetch(new URL('render-timing.json',base))).json(),baseline=await(await fetch(new URL('brand-baseline.json',base))).json();
const S=Object.fromEntries(tl.scenes.map(s=>[s.id,s]));baseline.total=tl.duration;baseline.introSec=2;baseline.condition=tl.condition;
for(const k of Object.keys(baseline.marks))baseline.marks[k]=1000;
Object.assign(baseline.marks,{h1:S.approach.start,h2:S.combine.start,h3:S.divide.start,ans:S.answer.start,cta:S.cta.start,link:S.cta.start+2});
baseline.sentences=[{id:'pause',start:tl.pause.start,end:tl.pause.end},{id:'s7',start:S.divide.start,end:S.divide.end},{id:'ans',start:S.answer.start,end:S.answer.end},{id:'cta',start:S.cta.start,end:S.cta.end}];
const story=makeStory(baseline);story.director=baseline;
const defs={
 cars:['','Навстречу друг другу','Старт одновременно','duo',''],
 speed_a:['','55 км/ч','скорость первого автомобиля','focus_a','За 1 час — 55 км'],
 speed_b:['','75 км/ч','скорость второго автомобиля','focus_b','За 1 час — 75 км'],
 distance:['','260 км','расстояние между городами','map',''],
 question:['','Когда встретятся?','Ищем время в пути','duo','t = ?'],
 approach:['Шаг 1 из 3','Сближаются','Обе машины едут навстречу','paths','С двух сторон — одновременно'],
 hour_a:['Шаг 1 из 3','За один час','Смотрим пройденные пути','hour_a','Первый автомобиль: 55 км'],
 hour_b:['Шаг 1 из 3','За тот же час','Оба автомобиля были в пути час','hour_b','Второй автомобиль: 75 км'],
 combine:['Шаг 2 из 3','Почему складываем?','Оба пути сокращают промежуток','map','55 + 75 = 130'],
 closing:['Шаг 2 из 3','130 км/ч','скорость сближения','paths','За час: расстояние −130 км'],
 divide:['Шаг 2 из 3','Ищем время','Считаем часовые участки','map','260 ÷ 130 = 2 часа'],
 verify_a:['Шаг 3 из 3','Проверяем пути','Первый автомобиль','paths','55 × 2 = 110 км'],
 verify_b:['Шаг 3 из 3','Проверяем пути','Второй автомобиль','paths','75 × 2 = 150 км'],
 verify_sum:['Шаг 3 из 3','Машины встретились','Промежуток равен нулю','meet','110 + 150 = 260 км'],
 answer:['Ответ','2 часа','Время до встречи','answer',''],
 cta:['','Больше заданий','в приложении — бесплатно','none','']};
story.headlines=tl.scenes.map(s=>[s.start,...defs[s.id].slice(0,3)]);story.headlines.push([tl.pause.start,'','','']);story.headlines.sort((a,b)=>a[0]-b[0]);
await Promise.all([500,600,700,800].map(w=>document.fonts.load(`${w} 40px Inter`,'АаЯя08x')));await document.fonts.ready;
const shape=await(await fetch(new URL('assets/logo-shape.json',base))).json(),logo=await new THREE.TextureLoader().loadAsync(new URL('assets/logo.png',base).href);logo.colorSpace=THREE.SRGBColorSpace;logo.anisotropy=8;
const stage=document.querySelector('#stage'),display=document.querySelector('#gl'),ctx=display.getContext('2d'),brandCanvas=document.createElement('canvas');brandCanvas.width=1080;brandCanvas.height=1920;
const overlay=createOverlay(stage,story),world=createWorld({canvas:brandCanvas,logoTexture:logo,logoN:shape.superellipseN,story});overlay.init(world);
const trafficCanvas=document.createElement('canvas');trafficCanvas.width=1080;trafficCanvas.height=850;const traffic=createTraffic(trafficCanvas);
function el(cls,html=''){const e=document.createElement('div');e.className=cls;e.innerHTML=html;stage.appendChild(e);return e;}
const noteWrap=el('note-wrap traffic-note','<div class="floor-shadow"></div><div class="note"><div class="note-top"><i></i><i></i><i></i><span>Разбираем по смыслу</span></div><div class="note-line"><span class="nl-text"></span></div></div>');noteWrap.style.top='1430px';
const note=noteWrap.querySelector('.note'),noteText=noteWrap.querySelector('.nl-text');
const labelA=el('sticker'),labelB=el('sticker violet'),distance=el('sticker'),mapLine=el('map-line'),bars=el('hour-blocks');
mapLine.style.cssText='position:absolute;z-index:3;left:285px;top:1180px;width:510px;height:4px;background:#7774d8;border-radius:2px;';mapLine.innerHTML='<i style="position:absolute;left:0;top:-8px;border-right:15px solid #7774d8;border-top:10px solid transparent;border-bottom:10px solid transparent"></i><i style="position:absolute;right:0;top:-8px;border-left:15px solid #7774d8;border-top:10px solid transparent;border-bottom:10px solid transparent"></i>';
bars.style.cssText='position:absolute;z-index:4;left:180px;top:1280px;display:flex;gap:12px;';bars.innerHTML='<div style="width:350px;padding:20px 0;border-radius:24px;background:#d8dfff;color:#4864ed;text-align:center;font-size:38px;font-weight:700;box-shadow:0 14px 25px #4a488c25">130 км · 1 час</div><div style="width:350px;padding:20px 0;border-radius:24px;background:#e2dcff;color:#7860df;text-align:center;font-size:38px;font-weight:700;box-shadow:0 14px 25px #4a488c25">130 км · 1 час</div>';
function sticker(e,text,x,y,k=1){e.textContent=text;e.style.display=text?'':'none';e.style.opacity=k;e.style.transform=`translate(${x}px,${y}px) translate(-50%,-50%) scale(${.88+.12*k})`;}
window.renderFrame=t=>{
 const s=[...tl.scenes].reverse().find(s=>t>=s.start),paused=t>=tl.pause.start&&t<tl.pause.end+.4,c=s?defs[s.id]:null;const content=!!s&&!paused&&s.id!=='cta';
 // Original brand renderer and shutter. Intro is replaced with original compressed frames at final assembly.
 const samples=t<2||t>S.cta.start-.1&&t<S.cta.start+1.35?9:1;ctx.clearRect(0,0,1080,1920);ctx.globalCompositeOperation=samples>1?'lighter':'source-over';ctx.globalAlpha=1/samples;
 for(let i=0;i<samples;i++){world.update(Math.max(0,t+(samples>1?(i/(samples-1)-.5)/120:0)),overlay.plaque);world.hideLegacy();world.render();ctx.drawImage(brandCanvas,0,0);}ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';overlay.update(t,display);
 for(const cls of ['.stickers','.notes','.eq-wrap','.flyers'])document.querySelector(cls).style.display='none';
 noteWrap.style.display='none';labelA.style.display=labelB.style.display=distance.style.display=mapLine.style.display=bars.style.display='none';
 if(content){const u=clamp((t-s.start-.2)/Math.max(.5,s.end-s.start-.7));let progress=u,hours=1;
 if(s.id==='hour_b')progress=1;
 if(s.id==='approach')hours=.4;
 if(s.id==='verify_a'){hours=2;progress=u;}
 if(['verify_b','verify_sum'].includes(s.id)){hours=2;progress=1;}
 traffic.update(t,{view:c[3],progress,hours});const fade=ease.outCubic(seg(t,s.start,s.start+.35));ctx.globalAlpha=fade;ctx.drawImage(trafficCanvas,0,670);ctx.globalAlpha=1;
 if(c[4]){noteWrap.style.display='';noteText.textContent=c[4];note.style.transform=`perspective(1500px) translateY(${(1-fade)*100}px) rotateX(${9+(1-fade)*24}deg) rotateY(${-5+Math.sin(t*.6)*1.5}deg)`;note.style.opacity=fade;}
 const pa=traffic.project(traffic.a.g.position.clone().add(new THREE.Vector3(0,1.7,0))),pb=traffic.project(traffic.b.g.position.clone().add(new THREE.Vector3(0,1.7,0)));
 if(['cars','question','approach','closing'].includes(s.id)){sticker(labelA,'55 км/ч',pa.x,pa.y-15,fade);sticker(labelB,'75 км/ч',pb.x,pb.y-15,fade);}
 if(['speed_a','speed_b'].includes(s.id))sticker(s.id==='speed_a'?labelA:labelB,s.id==='speed_a'?'55 км/ч':'75 км/ч',540,1250,fade);
 if(['hour_a','hour_b','verify_a','verify_b','verify_sum'].includes(s.id)){const aKm=s.id.startsWith('verify')?110:55,bKm=s.id.startsWith('verify')?150:75;sticker(labelA,aKm+' км',pa.x,pa.y-30,fade);sticker(labelB,bKm+' км',pb.x,pb.y-30,fade);}
 if(c[3]==='map'){sticker(labelA,'Город А',260,1250,fade);sticker(labelB,'Город Б',820,1250,fade);mapLine.style.display='';mapLine.style.opacity=fade;sticker(distance,s.id==='combine'?'55 + 75': '260 км',540,1180,fade);}
 if(s.id==='divide'){bars.style.display='flex';labelA.style.display=labelB.style.display='none';}
 }
 return true;
};
window.DURATION=tl.duration;window.FPS=120;window.ready=true;
