// One source for geometry, labels and arithmetic. Never fall back to fixture numbers.
export const SCENE_IDS = ['cars','speed_a','speed_b','distance','question','approach','hour_a','hour_b','combine','closing','divide','verify_a','verify_b','verify_sum','answer','cta'];
export const fmt = n => Number(n.toFixed(2)).toLocaleString('ru-RU');
export const hoursText = n => `${fmt(n)} ${n === 1 ? 'час' : n >= 2 && n <= 4 ? 'часа' : 'часов'}`;

export function trafficParameters(p) {
  for (const k of ['speed_a','speed_b','distance','answer_hours']) {
    if (!Number.isFinite(p?.[k]) || p[k] <= 0) throw Error(`Invalid traffic parameter: ${k}`);
  }
  const sum = p.speed_a + p.speed_b, hours = p.distance / sum;
  if (Math.abs(hours - p.answer_hours) > 1e-8) throw Error('Answer disagrees with distance and speeds');
  // This storyboard explicitly explains whole one-hour sections. Route other
  // problems to a different adapter, never silently draw two sections for them.
  if (!Number.isInteger(hours) || hours < 1 || hours > 6) throw Error('Unsupported traffic storyboard: require 1–6 whole hours');
  if (p.speed_a > 300 || p.speed_b > 300) throw Error('Unsupported road speed');
  return {...p, sum, hours, path_a:p.speed_a*hours, path_b:p.speed_b*hours};
}

export function validateTimeline(tl) {
  const p = trafficParameters(tl.parameters);
  if (tl.fps !== 120 || !Number.isFinite(tl.duration) || tl.duration <= 7) throw Error('Invalid duration/FPS');
  if (!Array.isArray(tl.scenes) || tl.scenes.map(s=>s.id).join(',') !== SCENE_IDS.join(',')) throw Error('Missing, duplicate or reordered semantic scene');
  let prev = 2;
  for (const s of tl.scenes) {
    if (!Number.isFinite(s.start) || !Number.isFinite(s.end) || s.start < prev-1e-5 || s.end <= s.start || s.end > tl.duration) throw Error(`Invalid speech cue: ${s.id}`);
    prev = s.end;
  }
  const q = tl.scenes[4], after = tl.scenes[5], pause = tl.pause;
  if (!pause || Math.abs(pause.start-q.end)>1/120 || Math.abs(pause.timerStart-pause.start-1)>1/120 || Math.abs(pause.end-pause.timerStart-4)>1/120 || after.start < pause.end) throw Error('Pause must settle for 1s, count for 4s, and contain no speech');
  if (typeof tl.condition !== 'string' || !tl.condition.trim()) throw Error('Missing screen condition');
  return p;
}

export function presentation(parameters) {
  const p=trafficParameters(parameters),a=fmt(p.speed_a),b=fmt(p.speed_b),d=fmt(p.distance),sum=fmt(p.sum),h=fmt(p.hours),ha=fmt(p.path_a),hb=fmt(p.path_b);
  return {
    cars:['','Навстречу друг другу','Старт одновременно','duo',''],
    speed_a:['',`${a} км/ч`,'скорость первого автомобиля','focus_a',`За 1 час — ${a} км`],
    speed_b:['',`${b} км/ч`,'скорость второго автомобиля','focus_b',`За 1 час — ${b} км`],
    distance:['',`${d} км`,'расстояние между городами','map',''],
    question:['','Когда встретятся?','Ищем время в пути','duo','t = ?'],
    approach:['Шаг 1 из 3','Сближаются','Обе машины едут навстречу','paths','С двух сторон — одновременно'],
    hour_a:['Шаг 1 из 3','За один час','Смотрим пройденные пути','hour_a',`Первый автомобиль: ${a} км`],
    hour_b:['Шаг 1 из 3','За тот же час','Оба автомобиля были в пути час','hour_b',`Второй автомобиль: ${b} км`],
    combine:['Шаг 2 из 3','Почему складываем?','Оба пути сокращают промежуток','map',`${a} + ${b} = ${sum}`],
    closing:['Шаг 2 из 3',`${sum} км/ч`,'скорость сближения','paths',`За час: расстояние −${sum} км`],
    divide:['Шаг 2 из 3','Ищем время','Считаем часовые участки','map',`${d} ÷ ${sum} = ${hoursText(p.hours)}`],
    verify_a:['Шаг 3 из 3','Проверяем пути','Первый автомобиль','paths',`${a} × ${h} = ${ha} км`],
    verify_b:['Шаг 3 из 3','Проверяем пути','Второй автомобиль','paths',`${b} × ${h} = ${hb} км`],
    verify_sum:['Шаг 3 из 3','Машины встретились','Промежуток равен нулю','meet',`${ha} + ${hb} = ${d} км`],
    answer:['Ответ',hoursText(p.hours),'Время до встречи','answer',''],
    cta:['','Больше заданий','в приложении — бесплатно','none','']
  };
}

// Distances in km, resolved independently of Three.js so regressions are testable.
export function distances(parameters,id,progress) {
  const p=trafficParameters(parameters),u=Math.max(0,Math.min(1,progress));
  let ah=0,bh=0;
  if (id==='hour_a') ah=u;
  else if(id==='hour_b'){ah=1;bh=u;}
  else if(id==='verify_a') ah=p.hours*u;
  else if(id==='verify_b'){ah=p.hours;bh=p.hours*u;}
  else if(id==='verify_sum'){ah=p.hours;bh=p.hours;}
  else if(id==='approach') ah=bh=Math.min(.4,p.hours)*u;
  else if(id==='closing') ah=bh=u;
  const a=p.speed_a*ah,b=p.speed_b*bh;
  return {a,b,remaining:Math.max(0,p.distance-a-b),xA:-4+8*a/p.distance,xB:4-8*b/p.distance};
}
