import assert from 'node:assert/strict';
import fs from 'node:fs';
import {trafficParameters,presentation,distances,validateTimeline} from './src/traffic-contract.js';
import {layoutIssues,requireCleanRender,frameRange} from './qa.mjs';
const base={speed_a:55,speed_b:75,distance:260,answer_hours:2};
let checks=0;
function check(name,fn){fn();checks++;console.log(`PASS ${name}`);}
check('same parameters drive geometry and text for three different lessons',()=>{
  for(const p of [base,{speed_a:60,speed_b:80,distance:420,answer_hours:3},{speed_a:40,speed_b:50,distance:90,answer_hours:1}]){
    const x=trafficParameters(p),defs=presentation(p),end=distances(p,'verify_sum',1);
    assert.ok(Math.abs(end.xA-end.xB)<1e-10);assert.equal(end.remaining,0);
    assert.equal(end.a+end.b,p.distance);assert.equal(defs.answer[1],`${p.answer_hours} ${p.answer_hours===1?'час':'часа'}`);
    assert.ok(defs.verify_b[4].endsWith(`${x.path_b} км`));
  }
});
check('second car really moves during its explanation',()=>{
  const a=distances(base,'hour_b',0),b=distances(base,'hour_b',.5),c=distances(base,'hour_b',1);
  assert.equal(a.a,55);assert.equal(a.b,0);assert.equal(b.b,37.5);assert.equal(c.b,75);
  assert.ok(a.xB>b.xB&&b.xB>c.xB);
});
check('verification does not show completed path before car moves',()=>{
  const a=distances(base,'verify_b',0),b=distances(base,'verify_b',.5),c=distances(base,'verify_b',1);
  assert.equal(a.a,110);assert.equal(a.b,0);assert.equal(b.b,75);assert.equal(c.b,150);
});
check('wrong answers, nonfinite values and unsupported storyboard fail',()=>{
  for(const p of [{...base,answer_hours:3},{...base,speed_a:NaN},{...base,speed_b:0},{...base,distance:325,answer_hours:2.5}])assert.throws(()=>trafficParameters(p));
});
const tl=JSON.parse(fs.readFileSync(new URL('./render-timing.json',import.meta.url)));
check('actual saved speech timeline passes',()=>validateTimeline(tl));
check('duplicated scene, missing pause and voice over countdown fail',()=>{
  for(const change of [t=>t.scenes[3].id='cars',t=>t.pause.timerStart++,t=>t.scenes[5].start=t.pause.start+.5,t=>t.scenes[3].end=NaN]){
    const t=structuredClone(tl);change(t);assert.throws(()=>validateTimeline(t));
  }
});
check('bounds, overlaps, JS failures and empty QA cannot pass',()=>{
  const b={x:0,y:0,w:100,h:100,text:'A'};
  assert.equal(layoutIssues([b]).length,0);
  for(const boxes of [[{...b,x:-2}],[{...b,x:NaN}],[b,{...b,text:'B'}]])assert.throws(()=>requireCleanRender([{issues:layoutIssues(boxes)}]));
  assert.throws(()=>requireCleanRender([]));assert.throws(()=>requireCleanRender([{issues:[]}],['pageerror']));
});
check('frame splitting covers exactly all frames',()=>{
  const n=Math.round(tl.duration*120),ranges=Array.from({length:6},(_,p)=>frameRange({fps:120,workers:1,from:Math.floor(n*p/6)/120,to:Math.floor(n*(p+1)/6)/120,duration:tl.duration}));
  assert.equal(ranges.reduce((n,r)=>n+r.last-r.first,0),n);
  for(let i=1;i<ranges.length;i++)assert.equal(ranges[i].first,ranges[i-1].last);
  assert.throws(()=>frameRange({fps:60,workers:1,from:0,to:1,duration:2}));
});
console.log(JSON.stringify({status:'code_checks_passed_video_not_verified',checks}));
