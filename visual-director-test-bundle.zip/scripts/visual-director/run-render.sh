#!/usr/bin/env bash
set -euo pipefail
node scripts/visual-director/test.mjs
node scripts/visual-director/test-timing.mjs
node scripts/visual-director/build-render-inputs.mjs render-inputs.json
node scripts/visual-director/test-choreography.mjs
python scripts/visual-director/montage-audio.py experiments/vessels-3d/assets/director-voice.mp3 experiments/vessels-3d/director-timing.json experiments/vessels-3d/assets/director-voice.wav
TIMES=$(node --input-type=module -e "import fs from 'node:fs';const t=JSON.parse(fs.readFileSync('experiments/vessels-3d/director-timeline.json')); console.log([0.7,1.8,...t.timing.scenes.map(s=>s.startSec+1),t.timing.pause.countdownStartSec+0.1,t.timing.pause.endSec-0.2].join(' '));")
node experiments/vessels-3d/render.mjs stills $TIMES
if [ "${RENDER_MODE:-stills}" = video ]; then
 node experiments/vessels-3d/render.mjs video --fps 120 --workers 3
 ffmpeg -y -v error -i experiments/vessels-3d/out/video-silent.mp4 -i experiments/vessels-3d/assets/director-voice.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -af apad -shortest -movflags +faststart experiments/vessels-3d/out/visual-director-test.mp4
 ffprobe -v error -show_streams -show_format -of json experiments/vessels-3d/out/visual-director-test.mp4 > experiments/vessels-3d/out/video-probe.json
fi
cp experiments/vessels-3d/director-timeline.json experiments/vessels-3d/out/
cp experiments/vessels-3d/assets/director-voice.wav.qa.json experiments/vessels-3d/out/
