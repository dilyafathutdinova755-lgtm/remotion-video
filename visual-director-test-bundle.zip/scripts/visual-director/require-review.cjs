const data=$('Validate visual direction').first().json;
if(!data.validation.structural_valid)throw new Error('STOP: invalid visual structure: '+data.validation.issues.join('; '));
const reply=$input.first().json;
if(reply.stop_reason!=='end_turn')throw new Error('STOP: incomplete independent review');
let raw=(reply.content??[]).filter(b=>b.type==='text').map(b=>b.text).join('\n').trim().replace(/^```(?:json)?\s*/,'').replace(/\s*```$/,'');
let review;try{review=JSON.parse(raw);}catch{throw new Error('STOP: invalid review JSON');}
if(review.correct!==true||!Array.isArray(review.issues)||review.issues.length||!Array.isArray(review.checks)||review.checks.length<3)throw new Error('STOP: independent review failed: '+JSON.stringify(review));
return [{json:{...data,independent_visual_review:review,validation:{...data.validation,semantic_verified:true,render_ready:false},status:data.validation.missing_renderer_kinds.length?'needs_renderer_assets':'awaiting_renderer_integration'}}];
