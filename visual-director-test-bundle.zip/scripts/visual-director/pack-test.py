from pathlib import Path
import zipfile,json
with zipfile.ZipFile('../handoff/visual-director-test-bundle.zip','w',zipfile.ZIP_DEFLATED) as z:
 for root in ['scripts/visual-director','experiments/vessels-3d']:
  for p in Path(root).rglob('*'):
   if not p.is_file() or any(x in p.parts for x in ['node_modules','out']) or p.suffix in ['.mp3','.wav']:continue
   if p.name=='n8n-director-test.json':
    w=json.loads(p.read_text());w.pop('meta',None)
    for n in w['nodes']:n.pop('credentials',None)
    z.writestr(str(p),json.dumps(w,ensure_ascii=False));continue
   z.write(p)
 z.write('render-inputs.json')
