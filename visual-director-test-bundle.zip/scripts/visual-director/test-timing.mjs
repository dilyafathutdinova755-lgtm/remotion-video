import assert from 'node:assert/strict';
import {compileTiming} from './compile-timing.mjs';
const input={segments:[{id:'task',kind:'task'},{id:'step1',kind:'solution'},{id:'cta',kind:'cta'}],
  alignment:[{id:'task',startSec:0,endSec:10.25},{id:'step1',startSec:10.25,endSec:21},{id:'cta',startSec:21,endSec:24}],pauseAfterId:'task'};
const result=compileTiming(input);
assert.equal(result.scenes[0].startSec,2);
assert.equal(result.pause.countdownStartSec,13.25);
assert.equal(result.pause.endSec-result.pause.countdownStartSec,4);
assert.equal(result.scenes[1].startSec,result.pause.endSec);
assert.equal(result.durationSec,31);
assert.equal(result.audioEdits[1].atSec,10.25);
for(const change of [
 x=>x.alignment.reverse(),x=>x.alignment.pop(),x=>x.alignment[1].startSec=9,
 x=>x.alignment[0].endSec=NaN,x=>x.pauseAfterId='missing',x=>x.fps=60,
 x=>x.segments[1].id='task',x=>x.pauseSeconds=-1,x=>x.pauseAfterId='step1',x=>x.segments[0].kind='solution',
]){const x=structuredClone(input);change(x);assert.throws(()=>compileTiming(x));}
console.log('Timing: measured boundaries, 4-second settled countdown, audio edits and 8 invalid inputs passed.');
