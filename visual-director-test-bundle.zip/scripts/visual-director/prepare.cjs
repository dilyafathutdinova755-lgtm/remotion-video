const input = $input.first().json;
for (const k of ['condition_text','answer','subject']) if(typeof input[k]!=='string'||!input[k].trim()) throw new Error('Missing '+k);
if(!Array.isArray(input.narration_segments)||!input.narration_segments.length) throw new Error('Missing narration_segments');
const ids=new Set();
for(const s of input.narration_segments){if(!s.id||ids.has(s.id)||typeof s.text!=='string')throw new Error('Invalid narration segment');ids.add(s.id);}
const q=input.solution_parameters;
if(q?.kind==='salt-mixture'){
 const {mass1:m,concentration1:a,concentration2:b,targetConcentration:c,answerMass:x}=q;
 if(![m,a,b,c,x].every(Number.isFinite)||m<=0||x<=0||[a,b,c].some(v=>v<0||v>100)||b===c)throw new Error('Invalid salt-mixture parameters');
 const computed=m*(c-a)/(b-c);
 if(Math.abs(computed-x)>1e-8||Math.abs((m*a+x*b)/(m+x)-c)>1e-8)throw new Error('Incorrect solution: mass balance failed');
 if(input.answer!==String(x).replace('.',',')+' кг')throw new Error('Answer differs from checked mass balance');
}
const task=JSON.parse(JSON.stringify(input));
const style={version:'ege-visual-director-v1',intro_seconds:2,pause_seconds:4,pause_transition_seconds:1,pause_start:'after_layout_settled',full_condition_on_pause:true,uniform_condition_text:true,blur_pause:false,show_subject_label:false,compact_notes:true,persistent_object_colors:true,replace_unknown_with_result:true,no_duplicate_cta_brand:true,brand_asset:'experiments/vessels-3d/assets/logo.png',render_fps:120};
const catalog={renderer:'threejs-vessels-experimental',implemented:['vessel','liquid','salt','brand_icon','note','formula','timer'],pending:['car','road','person','molecule','cell','organ','word_card'],actions:['appear','disappear','move','focus','pour','dissolve','replace_label']};
return [{json:{task,style,catalog,attempt:0}}];
