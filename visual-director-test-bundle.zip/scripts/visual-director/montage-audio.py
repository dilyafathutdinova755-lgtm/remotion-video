"""Insert physical silence into measured PCM; never synthesize time from text length."""
import json,subprocess,sys,wave
from pathlib import Path
import numpy as np
src,timing_file,dest=sys.argv[1:]
timing=json.loads(Path(timing_file).read_text())
pcm=subprocess.check_output(['ffmpeg','-v','error','-i',src,'-f','s16le','-ac','1','-ar','48000','-'])
x=np.frombuffer(pcm,dtype='<i2').copy();sr=48000
p=round(timing['pause']['spliceAtSec']*sr)
if not 0<p<len(x):raise ValueError('Pause outside audio')
# Fade only within 5 ms at the splice, to avoid a discontinuity. Alignment end is after the spoken segment.
k=min(240,p,len(x)-p)
x[p-k:p]=(x[p-k:p]*np.linspace(1,0,k)).astype(np.int16)
x[p:p+k]=(x[p:p+k]*np.linspace(0,1,k)).astype(np.int16)
intro=np.zeros(round(timing['intro']['endSec']*sr),dtype='<i2')
silence=np.zeros(round(timing['pause']['silenceSeconds']*sr),dtype='<i2')
y=np.concatenate([intro,x[:p],silence,x[p:]])
with wave.open(dest,'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(sr);w.writeframes(y.tobytes())
a=round(timing['pause']['startSec']*sr);b=a+len(silence)
assert np.max(np.abs(y[a:b]))==0
Path(dest+'.qa.json').write_text(json.dumps({'sample_rate':sr,'duration_sec':len(y)/sr,'silence_start':a/sr,'silence_end':b/sr,'silence_peak':0,'countdown_seconds':timing['pause']['endSec']-timing['pause']['countdownStartSec']}))
