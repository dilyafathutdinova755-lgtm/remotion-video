import fs from 'node:fs';
import {makeStory} from '../../experiments/vessels-3d/src/story.js';
import {makeChoreo} from '../../experiments/vessels-3d/src/choreo.js';
const tl=JSON.parse(fs.readFileSync('experiments/vessels-3d/director-timeline.json'));
const c=makeChoreo(makeStory(tl).T);
function check(v,path='state'){if(typeof v==='number'&&!Number.isFinite(v))throw Error('Nonfinite '+path);if(v&&typeof v==='object')for(const [k,a]of Object.entries(v))check(a,path+'.'+k);}
for(let f=0;f<Math.ceil(tl.total*120);f++){const t=f/120;check(c.states(t,{shadow:[38,40,110],shadowA:.42}));check(c.camera(t));}
console.log('All 120fps choreography frames have finite transforms and camera values');
