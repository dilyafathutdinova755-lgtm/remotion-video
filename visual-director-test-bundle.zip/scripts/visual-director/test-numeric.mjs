import fs from 'node:fs';
import assert from 'node:assert/strict';
import {compileVessels} from './compile-vessels.mjs';
const original=JSON.parse(fs.readFileSync('render-inputs.json'));
const a=compileVessels(original.data,original.speech);
assert.equal(a.numeric.x,'8');assert.equal(a.numeric.salt,'0,8');
// A compiler-only regression fixture: synthetic parameter substitution, not a reviewed video.
const variant=structuredClone(original);
variant.data.task.solution_parameters={kind:'salt-mixture',mass1:12,concentration1:5,concentration2:35,targetConcentration:15,answerMass:6};
const b=compileVessels(variant.data,variant.speech);
assert.deepEqual([b.numeric.m,b.numeric.x,b.numeric.salt,b.numeric.rhs,b.numeric.delta],['12','6','0,6','1,2','0,2']);
variant.data.task.solution_parameters.answerMass=8;
assert.throws(()=>compileVessels(variant.data,variant.speech),/mass balance/);
console.log('Numeric compiler: original 8 kg and alternative 6 kg; inconsistent answer rejected. Alternative is unit data, not semantic/video approval.');
