const prepared=$('Prepare visual direction').first().json;
const envelope=$input.first().json;
const blocks=envelope.content;
if(envelope.stop_reason!=='end_turn'||!Array.isArray(blocks))throw new Error('Incomplete director response');
let raw=blocks.filter(b=>b.type==='text').map(b=>b.text).join('\n').trim();
raw=raw.replace(/^```(?:json)?\s*/,'').replace(/\s*```$/,'');
let p;try{p=JSON.parse(raw);}catch{throw new Error('Director returned invalid JSON');}
if(!p||typeof p!=='object'||Array.isArray(p))throw new Error('Director plan must be an object');
const issues=[];const check=(ok,m)=>{if(!ok)issues.push(m);};
check(p.version==='visual-scene-plan-v1','Invalid version');
check(Array.isArray(p.objects)&&p.objects.length>0&&p.objects.length<=24,'Invalid objects');
check(Array.isArray(p.scenes)&&p.scenes.length>0&&p.scenes.length<=24,'Invalid scenes');
const brandSource='ЕГЭ Тренажёр\nСсылка на ЕГЭ Тренажёр в шапке профиля.\nСкачивай бесплатно\nСсылка в профиле';
const objectIds=new Set(), segmentIds=new Set(prepared.task.narration_segments.map(s=>s.id));
const kinds=[...prepared.catalog.implemented,...prepared.catalog.pending];
for(const o of Array.isArray(p.objects)?p.objects:[]){if(!o||typeof o!=='object'){issues.push('Invalid object');continue;}check(typeof o.id==='string'&&/^[a-z][a-z0-9_-]{0,48}$/.test(o.id)&&!objectIds.has(o.id),'Invalid object id');objectIds.add(o.id);check(kinds.includes(o.kind),'Unknown kind');check(typeof o.description==='string'&&o.description.length<=1800,'Missing description');check(typeof o.source_excerpt==='string'&&o.source_excerpt.length>0&&(prepared.task.condition_text+'\n'+(prepared.task.instruction??'')+'\n'+(prepared.task.explanation??'')+'\n'+brandSource).includes(o.source_excerpt),'Object lacks grounded source');if(o.color)check(/^#[0-9a-f]{6}$/i.test(o.color),'Invalid color');}
const seen=new Set();
for(const [sceneIndex,s] of (Array.isArray(p.scenes)?p.scenes:[]).entries()){if(!s||typeof s!=='object'){issues.push('Invalid scene');continue;}check(s.segment_id===prepared.task.narration_segments[sceneIndex]?.id,'Scenes out of narration order');check(segmentIds.has(s.segment_id)&&!seen.has(s.segment_id),'Unknown/duplicate segment');seen.add(s.segment_id);check(typeof s.focus==='string'&&objectIds.has(s.focus),'Invalid focus');check(Array.isArray(s.events)&&s.events.length<=30,'Invalid events');check(Array.isArray(s.labels)&&s.labels.length<=5,'Too many labels');for(const l of Array.isArray(s.labels)?s.labels:[]){if(!l||typeof l!=='object'){issues.push('Invalid label');continue;}check(typeof l.text==='string'&&l.text.length<=160,'Oversized label');check(objectIds.has(l.object_id),'Unanchored label');check(typeof l.source_excerpt==='string'&&l.source_excerpt.length>0&&(prepared.task.condition_text+'\n'+(prepared.task.instruction??'')+'\n'+(prepared.task.explanation??'')+'\n'+brandSource+'\n'+prepared.task.answer).includes(l.source_excerpt),'Ungrounded label');}
for(const e of Array.isArray(s.events)?s.events:[]){if(!e||typeof e!=='object'){issues.push('Invalid event');continue;}check(objectIds.has(e.object_id),'Unknown event object');check(prepared.catalog.actions.includes(e.action),'Unsupported action');check(typeof e.cue==='string'&&e.cue.trim().length>0&&prepared.task.narration_segments.find(n=>n.id===s.segment_id)?.text.includes(e.cue),'Cue absent from narration');const text=prepared.task.narration_segments.find(n=>n.id===s.segment_id)?.text??'';if(typeof e.cue==='string'&&e.cue){const matches=[...text.matchAll(new RegExp(e.cue.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'g'))];const occurrence=e.occurrence??1;check(Number.isInteger(occurrence)&&occurrence>=1&&occurrence<=matches.length,'Invalid cue occurrence');check(matches.length<=1||e.occurrence!==undefined,'Ambiguous cue requires occurrence');if(matches[occurrence-1])e.span={start:matches[occurrence-1].index,end:matches[occurrence-1].index+e.cue.length};}if(e.target_id)check(objectIds.has(e.target_id),'Unknown event target');}}
check(seen.size===segmentIds.size,'Uncovered narration segments');
check(Array.isArray(p.semantic_checks)&&p.semantic_checks.length>=3,'Missing semantic self-checks');
const needed=(Array.isArray(p.objects)?p.objects:[]).filter(o=>o&&prepared.catalog.pending.includes(o.kind)).map(o=>o.kind);
return [{json:{...prepared,visual_plan:p,validation:{structural_valid:issues.length===0,issues,missing_renderer_kinds:[...new Set(needed)],semantic_verified:false,render_ready:false},status:issues.length?'needs_repair':'needs_independent_review'}}];
