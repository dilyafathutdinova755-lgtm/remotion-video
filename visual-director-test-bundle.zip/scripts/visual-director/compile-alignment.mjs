import {compileTiming} from './compile-timing.mjs';
export function compileAlignedPlan(data, speech) {
 if(!data.validation?.semantic_verified||!data.validation?.structural_valid)throw Error('Unverified plan');
 if(data.validation.missing_renderer_kinds.length)throw Error('Unsupported assets');
 const segments=data.task.narration_segments;
 const transcript=segments.map(s=>s.tts_text??s.text).join('\n\n');
 const a=speech.alignment;
 if(!a||a.characters.join('')!==transcript)throw Error('Speech alignment transcript mismatch');
 if(a.characters.length!==a.character_start_times_seconds.length||a.characters.length!==a.character_end_times_seconds.length)throw Error('Alignment length mismatch');
 let prev=0;
 for(let i=0;i<a.characters.length;i++){const st=a.character_start_times_seconds[i],en=a.character_end_times_seconds[i];if(!Number.isFinite(st)||!Number.isFinite(en)||st<prev-1e-5||en<st)throw Error('Invalid character alignment');prev=en;}
 let cursor=0;
 const maps=new Map();
 const alignment=segments.map(s=>{const text=s.tts_text??s.text;const offset=cursor;cursor+=Array.from(text).length+2;maps.set(s.id,{offset,text});return {id:s.id,startSec:a.character_start_times_seconds[offset],endSec:a.character_end_times_seconds[cursor-3]};});
 const pauseAfterId=segments.filter(s=>s.kind==='task').at(-1)?.id;
 const timing=compileTiming({segments,alignment,pauseAfterId});
 const events=data.visual_plan.scenes.flatMap(sc=>sc.events.map(e=>{
   const s=segments.find(s=>s.id===sc.segment_id),map=maps.get(s.id);
   // Identity mapping is exact for pre-normalized narration. Non-identity requires explicit spans.
   let span=e.span;
   if(map.text!==s.text){const match=s.tts_span_map?.find(m=>m.source_start===span?.start&&m.source_end===span?.end);if(!match)throw Error('Missing source-to-TTS span map');span={start:match.tts_start,end:match.tts_end};}
   if(!span||s.text.slice(e.span.start,e.span.end)!==e.cue)throw Error('Cue span mismatch');
   const idx=map.offset+Array.from(map.text.slice(0,span.start)).length;
   const scene=timing.scenes.find(t=>t.id===s.id),raw=alignment.find(t=>t.id===s.id);
   return {...e,segment_id:s.id,atSec:a.character_start_times_seconds[idx]+scene.startSec-raw.startSec};
 }));
 return {...data,timing,events,alignmentSource:'elevenlabs-character-alignment-v1',render_ready:false};
}
