import fs from 'node:fs';
import {compileVessels} from './compile-vessels.mjs';
const {data,speech}=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
const tl=compileVessels(data,speech);
fs.writeFileSync('experiments/vessels-3d/director-timeline.json',JSON.stringify(tl,null,2));
fs.writeFileSync('experiments/vessels-3d/assets/director-voice.mp3',Buffer.from(speech.audio_base64,'base64'));
fs.writeFileSync('experiments/vessels-3d/director-timing.json',JSON.stringify(tl.timing));
console.log(JSON.stringify({duration:tl.total,pause:tl.timing.pause,events:tl.events.length,fps:120}));
