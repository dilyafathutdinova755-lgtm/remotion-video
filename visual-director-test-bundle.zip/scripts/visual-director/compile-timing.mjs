// Input timestamps must come from measured speech alignment, before silence insertion.
// This compiler does not guess timings from text length or speech rate.
export function compileTiming({segments, alignment, pauseAfterId, introSeconds=2,
  settleSeconds=1, pauseSeconds=4, fps=120}) {
  const fail=m=>{throw new Error(m);};
  if(fps!==120)fail('Visual director requires 120 FPS');
  for(const n of [introSeconds,settleSeconds,pauseSeconds])
    if(!Number.isFinite(n)||n<0)fail('Invalid interval');
  if(!Array.isArray(segments)||!segments.length||!Array.isArray(alignment)||alignment.length!==segments.length)
    fail('Missing measured alignment');
  if(segments.filter(s=>s.id===pauseAfterId).length!==1)fail('Missing unique condition boundary');
  const taskSegments=segments.filter(s=>s.kind==='task');
  if(!taskSegments.length||taskSegments.at(-1).id!==pauseAfterId)fail('Pause must follow final task segment');
  const boundary=segments.findIndex(s=>s.id===pauseAfterId);
  if(segments.slice(0,boundary+1).some(s=>s.kind!=='task'))fail('Condition must precede solution');
  if(introSeconds!==2||pauseSeconds!==4)fail('Brand and countdown duration must be preserved');
  const ids=new Set();let previousEnd=0,shift=introSeconds,pause=null;
  const scenes=segments.map((segment,i)=>{
    const a=alignment[i];
    if(!segment.id||ids.has(segment.id)||a.id!==segment.id)fail('Alignment order mismatch');
    ids.add(segment.id);
    if(!Number.isFinite(a.startSec)||!Number.isFinite(a.endSec)||a.startSec<previousEnd-0.000001||a.endSec<=a.startSec)
      fail('Invalid measured interval');
    previousEnd=a.endSec;
    const scene={id:segment.id,startSec:a.startSec+shift,endSec:a.endSec+shift};
    if(segment.id===pauseAfterId){
      pause={spliceAtSec:a.endSec,startSec:scene.endSec,
        countdownStartSec:scene.endSec+settleSeconds,endSec:scene.endSec+settleSeconds+pauseSeconds,
        silenceSeconds:settleSeconds+pauseSeconds};
      shift+=pause.silenceSeconds;
    }
    return scene;
  });
  return {fps,intro:{startSec:0,endSec:introSeconds},scenes,pause,
    durationSec:Math.max(scenes.at(-1).endSec,pause.endSec),
    audioEdits:[{atSec:0,silenceSeconds:introSeconds},
      {atSec:pause.spliceAtSec,silenceSeconds:pause.silenceSeconds}]};
}
