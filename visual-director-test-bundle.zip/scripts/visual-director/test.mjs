import fs from 'node:fs';
import assert from 'node:assert/strict';
const root=new URL('./',import.meta.url);
const read=n=>fs.readFileSync(new URL(n,root),'utf8');
const run=(file,input,nodes={})=>new Function('$input','$',read(file))({first:()=>({json:input})},n=>({first:()=>({json:nodes[n]})}))[0].json;
const fixture=JSON.parse(read('fixture.json'));
const prepared=run('prepare.cjs',fixture);
assert.equal(prepared.style.pause_seconds,4);
assert.deepEqual(prepared.task,fixture);
const valid={version:'visual-scene-plan-v1',objects:[{id:'vessel_a',kind:'vessel',description:'Прозрачная ёмкость с мягкой тенью; уровень условный, масса показывается подписью.',source_excerpt:'раствора соли',color:'#3f74ff'}],scenes:fixture.narration_segments.map(s=>({segment_id:s.id,focus:'vessel_a',composition:'Сосуд в центре, компактная заметка ниже',labels:[],events:[{object_id:'vessel_a',action:'focus',cue:s.text,occurrence:1,description:'Плавное приближение; остальные элементы спокойны.'}]})),semantic_checks:['Единицы — кг','Концентрация — массовая доля','До паузы нет ответа']};
const response=p=>({stop_reason:'end_turn',content:[{type:'text',text:JSON.stringify(p)}]});
const validate=p=>run('validate.cjs',response(p),{'Prepare visual direction':prepared});
assert.equal(validate(valid).validation.structural_valid,true);
assert.equal(validate(valid).validation.render_ready,false);
let tests=2;
for(const change of [
 p=>p.scenes[0].events[0].cue='непроизнесённая фраза',
 p=>p.scenes[0].events[0].object_id='missing',
 p=>p.scenes[0].labels=[{object_id:'vessel_a',text:'a'.repeat(200),source_excerpt:'8 кг'}],
 p=>p.objects[0].source_excerpt='несуществующее условие',
 p=>p.objects[0].kind='remote_executable',
 p=>p.scenes.pop(),
 p=>p.scenes.reverse(),
 p=>p.scenes[0].events[0].cue='',
 p=>p.objects={},
 p=>p.objects=[null],
 p=>p.scenes[0].labels=[null],
 p=>p.scenes[0].events=[null],
 p=>p.scenes[1].segment_id=p.scenes[0].segment_id,
]){const p=structuredClone(valid);change(p);assert.equal(validate(p).validation.structural_valid,false);tests++;}
assert.throws(()=>run('validate.cjs',{stop_reason:'max_tokens',content:[]},{'Prepare visual direction':prepared}));tests++;
const checked=validate(valid);
const reviewed=run('require-review.cjs',response({correct:true,issues:[],checks:['one','two','three']}),{'Validate visual direction':checked});
assert.equal(reviewed.validation.semantic_verified,true);assert.equal(reviewed.validation.render_ready,false);tests++;
assert.throws(()=>run('require-review.cjs',response({correct:false,issues:['wrong concentration'],checks:[]}),{'Validate visual direction':checked}));tests++;
assert.throws(()=>run('prepare.cjs',{...fixture,narration_segments:[fixture.narration_segments[0],fixture.narration_segments[0]]}));tests++;
const w=JSON.parse(read('n8n-director-test.json'));const names=new Set(w.nodes.map(n=>n.name));
assert.equal(w.active,false);assert.equal(names.size,w.nodes.length);
for(const n of w.nodes){if(n.type.endsWith('.code'))new Function('$input','$',n.parameters.jsCode);if(n.parameters.jsonBody)new Function('$json','return '+n.parameters.jsonBody.slice(3,-2));}
for(const outs of Object.values(w.connections))for(const arr of outs.main)for(const c of arr)assert(names.has(c.node));
assert(!w.nodes.some(n=>/googleSheets|webhook|scheduleTrigger/.test(n.type)));tests++;
console.log(`${tests} checks passed. This validates code and negative cases, not a live Claude response or rendered video.`);
