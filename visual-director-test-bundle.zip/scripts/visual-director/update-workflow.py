import json,uuid,copy
from pathlib import Path
D=Path(__file__).parent
w=json.loads((D/'n8n-director-test.json').read_text())
nodes={n['name']:n for n in w['nodes']}
for name,file in [('Prepare visual direction','prepare.cjs'),('Validate visual direction','validate.cjs'),('Require verified visual plan','require-review.cjs')]:nodes[name]['parameters']['jsCode']=(D/file).read_text()
nodes['Test task — salt solution']['parameters']['jsCode']='return [{json:'+ (D/'fixture.json').read_text()+'}];'
for name,file,tokens in [('Generate visual direction','director-prompt.txt',6000),('Review visual semantics','review-prompt.txt',2400)]:
 n=nodes[name];prompt=(D/file).read_text().replace('\\n','\n').replace('\\"','"'); content='$json' if 'Generate' in name else '{task:$json.task,style:$json.style,plan:$json.visual_plan,validation:$json.validation}'
 n['parameters']['jsonBody']='={{ JSON.stringify({model:"claude-sonnet-4-5-20250929",max_tokens:'+str(tokens)+',system:'+json.dumps(prompt,ensure_ascii=False)+',messages:[{role:"user",content:JSON.stringify('+content+')}]}) }}'
 n['notes']='Isolated visual director test. No publication. API retries disabled.';n['retryOnFail']=False
# One structural repair, with no back edge and a maximum of three Claude calls.
initial=nodes['Validate visual direction'];initial['name']='Initial structural validation'
initial['parameters']['jsCode']='try {\n'+initial['parameters']['jsCode']+'\n} catch(e) {return [{json:{...$("Prepare visual direction").first().json,validation:{structural_valid:false,issues:[e.message]},status:"needs_repair"}}];}'
def code(name,src,pos):return {'id':str(uuid.uuid4()),'name':name,'type':'n8n-nodes-base.code','typeVersion':2,'position':pos,'parameters':{'jsCode':src}}
branch={'id':str(uuid.uuid4()),'name':'Plan structure valid?','type':'n8n-nodes-base.if','typeVersion':2.2,'position':[1300,0],'parameters':{'conditions':{'options':{'caseSensitive':True,'leftValue':'','typeValidation':'strict','version':2},'conditions':[{'id':str(uuid.uuid4()),'leftValue':'={{ $json.validation.structural_valid }}','rightValue':'','operator':{'type':'boolean','operation':'true','singleValue':True}}],'combinator':'and'},'options':{}}}
repair=copy.deepcopy(nodes['Generate visual direction']);repair.update(id=str(uuid.uuid4()),name='Repair visual direction once',position=[1500,260]);repair['parameters']['jsonBody']=repair['parameters']['jsonBody'].replace('JSON.stringify($json)','JSON.stringify({...$json,attempt:1,repair_instruction:"Исправь все validation.issues. Верни полный исправленный JSON, без объяснений."})')
revalidate=code('Validate repaired direction',(D/'validate.cjs').read_text(),[1730,260])
final=code('Validate visual direction','return $input.all();',[1950,0])
w['nodes'] += [branch,repair,revalidate,final]
def edge(dest):return {'node':dest,'type':'main','index':0}
w['connections']['Generate visual direction']={'main':[[edge('Initial structural validation')]]}
w['connections']['Initial structural validation']={'main':[[edge('Plan structure valid?')]]}
w['connections']['Plan structure valid?']={'main':[[edge('Validate visual direction')],[edge('Repair visual direction once')]]}
w['connections']['Repair visual direction once']={'main':[[edge('Validate repaired direction')]]}
w['connections']['Validate repaired direction']={'main':[[edge('Validate visual direction')]]}
w['active']=False
w.pop('id',None)
(D/'n8n-director-test.json').write_text(json.dumps(w,ensure_ascii=False,indent=2))
