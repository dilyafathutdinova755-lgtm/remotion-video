// Deterministic trusted assets are supplied by the application, never invented by a model.
const d=$input.first().json;
const p=structuredClone(d.visual_plan);
if(!p||!Array.isArray(p.objects))throw new Error('Missing plan');
const refs=p.scenes.flatMap(s=>[s.focus,...s.events.map(e=>e.object_id)]);
if(refs.includes('brand_icon')&&!p.objects.some(o=>o.id==='brand_icon'))p.objects.push({id:'brand_icon',kind:'brand_icon',description:'Настоящая иконка приложения из доверенного локального файла. Вращение и перенос в плашку.',source_excerpt:'ЕГЭ Тренажёр'});
return [{json:{...d,visual_plan:p}}];
