import {compileAlignedPlan} from './compile-alignment.mjs';
export function compileVessels(data,speech){
 const c=compileAlignedPlan(data,speech),q=data.task.solution_parameters;
 if(q?.kind!=='salt-mixture')throw Error('Only salt-mixture renderer is supported');
 const {mass1:m,concentration1:a,concentration2:b,targetConcentration:z,answerMass:x}=q;
 if(![m,a,b,z,x].every(Number.isFinite)||m<=0||x<=0||Math.abs(m*(z-a)/(b-z)-x)>1e-8)throw Error('Invalid mass balance');
 const ids=new Map(data.visual_plan.objects.map(o=>[o.id,o]));
 for(const id of ['vessel_1','vessel_2','vessel_result'])if(ids.get(id)?.kind!=='vessel')throw Error('Missing supported vessel role '+id);
 if(data.visual_plan.objects.some(o=>!['vessel','formula','brand_icon'].includes(o.kind)))throw Error('Plan requires unimplemented asset');
 const event=(id,action,segment,required=true)=>{const e=c.events.find(e=>e.object_id===id&&e.action===action&&(!segment||e.segment_id===segment));if(!e&&required)throw Error('Missing renderer event '+[id,action,segment]);return e?.atSec;};
 const sc=id=>{const s=c.timing.scenes.find(s=>s.id===id);if(!s)throw Error('Missing supported narration segment '+id);return s;};
 const marks={v1:event('vessel_1','appear','task'),v2:event('vessel_2','appear','task'),v3:event('vessel_result','appear',undefined),h1:sc('step1').startSec,h2:sc('step2').startSec,h3:sc('step3').startSec,ans:sc('answer').startSec,cta:sc('cta').startSec};
 marks.salt=marks.v1;marks.v2b=marks.v2;marks.q=marks.v2;marks.p20=marks.v3;
 marks.s1a=event('vessel_1','focus','step1',false)??marks.h1;
 marks.s2a=event('vessel_2','focus','step1',false);
 if(marks.s2a===undefined)throw Error('Missing second-vessel speech focus');
 marks.s1b=marks.s1a;marks.s2b=marks.s2a;
 marks.m1=Math.min(event('vessel_1','pour','step2'),event('vessel_2','pour','step2'));
 marks.pourB=event('vessel_2','pour','step2');marks.m2=marks.m1;marks.m3=marks.m1;
 marks.eq0=marks.m1+3.2;marks.eq1=event('formula_1','appear','step2');marks.eq2=marks.eq1;
 marks.br=marks.h3;marks.mv=c.events.find(e=>e.segment_id==='step3'&&e.action==='replace_label')?.atSec??marks.h3;
 marks.num=marks.mv;marks.r1=marks.mv;marks.r2=marks.ans;
 marks.a8=event('vessel_2','replace_label','answer');marks.link=marks.cta+1;
 // Fixed choreography needs time for the completed pour, never hide midway.
 if(marks.m1+3.1>sc('step3').endSec)throw Error('Speech too short for safe pour choreography');
 const sentences=c.timing.scenes.map(s=>({id:s.id==='answer'?'ans':s.id,start:s.startSec,end:s.endSec,text:data.task.narration_segments.find(n=>n.id===s.id).text}));
 sentences.push({id:'pause',start:c.timing.pause.startSec,end:c.timing.pause.endSec},{id:'s7',start:sc('step3').startSec,end:sc('step3').endSec});
 const fmt=n=>Number(n.toFixed(6)).toString().replace('.',',');
 return {...c,total:c.timing.durationSec+1,introSec:2,sentences,marks,parameters:q,condition:data.task.condition_text,
  numeric:{m:fmt(m),a:fmt(a),b:fmt(b),z:fmt(z),x:fmt(x),salt:fmt(m*a/100),ca:fmt(a/100),cb:fmt(b/100),cz:fmt(z/100),delta:fmt((b-z)/100),rhs:fmt(m*(z-a)/100),expanded:fmt(m*z/100),totalMass:fmt(m+x)},
  layout:{version:'vessels-layout-v1',width:1080,height:1920,header:[60,420,960,190],objects:[60,680,960,610],notes:[90,1320,900,350],condition:[60,520,960,650],timer:[60,1220,960,230]},render_ready:false};
}
